export interface UserDTO {
  userName: string;
  userEmail: string;
  userPhoneNumber: string;
  userPassword: string;
  userAddress: string;
}
